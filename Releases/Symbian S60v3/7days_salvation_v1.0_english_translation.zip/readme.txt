################################################################
7 Days Salvation English Translation Release v1.0 (October 2021)
################################################################

## Intro ##
7 Days is a 3D adventure game about a famous horror novelist, Salvator Ken, 
who is 30 years old, quite dissocial. He used to lock himself in his villa and think 
about his novel alone. One day, something strange happened, he was trapped in his house! 
He can‘t escape! Is it just a dream? If it is, when could he wake up?

7 Days tells a story about what happened to Ken in these days. In the game, the player's 
choice and interaction may affect the following events. It's a game quite worth thinking, 
but for the light users, the fine graphics, vivid sounds, and interesting puzzles will 
also bring them a great fun!

This game has been tested on a nokia n95 and an ngage without issues, also, it has been 
tested on the EKA2L1 emulator with 5320 and ngage roms.



## Details ##

The patch uses the full Chinese version of the game. A font and days from the first 
to the fifth day have been injected from the dingoo a320 console version and the english 
demo version of the game. Fonts, texts, and images have been adjusted for correct display 
on the symbian version. An automatic translation from Chinese to English has been performed 
as well as the translation and modification of the remaining images for days 6 and 7.



## Installation ##

Install the .sis file as if you were installing another game/app in your phone or
using the eka2l1 emulator.



## Addons ##

- There are 2 main endings in the game various easter eggs you can find in different
levels. Every ending unlocks new customes and an special weapon. I added a config file that 
has everything unlocked from the beggining of the game. You can use it by copying the 
"config.sdt" file included in this patch into the folder of the game in your symbian phone 
or your emulator drive on "system\apps\SevenDays". 

- I also added a walkthrough on pdf automatically translated from:
https://baike.baidu.com/item/七夜/5636595



## Credits ##

EsperKnight 	- 	Hacking
SnowyAria   	- 	Hacking
Mr. Nobody  	- 	Hacking
			Assets design
			ZH - English text translation

Thanks to Minexew, Yoti and Vitaly Ostrosablin for contruting with the Soft3d
engine archaeology which was used partially for the translation purposes of the game.
https://github.com/minexew/Soft3D-RE

Thanks to warchief-man for creating the Spk extractor which was used partially for the 
translation purposes of the game.
https://sourceforge.net/projects/spkextractor/files/

Thanks to the EKA2L1 team, without their emulator the translation of this game would 
have been infinitely more difficult.
https://12z1.com/



## Contact ##
Have any issues or run into any problems? Feel free to drop by our discord here:
*  https://discord.gg/bewGNtm

Alternatively, you can message Mr.Nobody on ROMhacking.net or on Twitter at @mrnobodystudios