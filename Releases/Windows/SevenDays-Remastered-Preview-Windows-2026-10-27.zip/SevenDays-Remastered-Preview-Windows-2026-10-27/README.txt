﻿SevenDays - Remastered Preview
Windows 64 位预览版 · 2026-10-27

一、启动

完整解压 ZIP 后，双击“七夜 - 重制预览.bat”或 SevenDays.exe。
默认启用 GPU 场景渲染、1280×960 场景、自适应连续光照和柔化角色阴影。
“七夜 - 原版渲染.bat”使用软件渲染，供画面对照。
请保留 assets 文件夹和全部 DLL，不要只复制 EXE。建议放在可写目录。
此包尚未启用 DLSS / RTX Remix 神经增强。

二、键盘

方向键 / W A S D    移动；在菜单中选择项目
Enter / 小键盘Enter / Space    确认、交互；具体动作依游戏场景而定
Esc                 返回 / 取消（不是立即退出程序）
Tab                 地图
M                   游戏内菜单
F8                  循环切换键鼠 / 手柄 / 自动输入模式
F9                  请求切换简体中文
F10                 请求切换英文
F11                 打开 / 关闭屏幕控件布局编辑器（不是全屏快捷键）

退出请关闭游戏窗口。外部设置或布局编辑面板打开时，游戏操作输入会被屏蔽；
先关闭面板再继续操作。F8/F9/F10 请在外部面板关闭时使用。
若键盘无响应，检查 PC 输入模式是否设为 gamepad；按 F8 切回键鼠或 auto。

三、鼠标与手柄

鼠标可点击屏幕上的方向、动作和外部设置控件。请不要按现代鼠标视角游戏理解操作。
标准手柄：左摇杆 / 十字键移动；南侧按钮（Xbox A）确认 / 交互；
东侧按钮（Xbox B）返回；Start 打开游戏菜单；Back / View 打开地图。
使用手柄时，将 PC 输入模式设为 auto 或 gamepad。

四、外部设置：运行中可切换

点击画面外侧 SET / 滑杆图标打开设置，再点击同一图标关闭。
每行点击一次切换一个值。游戏内 M 菜单与这个外部设置面板是两个入口。

GPU SHADOW    SOFT 为柔化角色阴影，ORIGINAL 为原版硬边黑影；下一帧生效，无需重启。
IMAGE         输出画面处理，包含 Original、Pixel Perfect、Smooth、Sharpen、
              Handheld LCD、Soft CRT、Smart Sharpen；默认 Smart Sharpen。
              Original 适合对照原始场景；这些是显示处理，不是 DLSS。
FPS           游戏逻辑更新率：16 / 30 / 60；不等同于独立的显示帧率上限。
AUDIO         Original / Remaster 音频资产；可用重制声音依包内资产覆盖情况而定。
PC            键鼠、手柄或自动输入模式。
MODE          屏幕移动控件：方向键 / 摇杆。
TOUCH         屏幕操作控件显示策略：始终、自动或隐藏。
OP            屏幕控件透明度。
DIR           摇杆四方向 / 八方向判定。
PRESET        控件布局预设。
EDIT          进入控件布局编辑器，可拖动控件；F11 可关闭编辑器。
RESET         重置当前控件布局，可能覆盖自己的布局调整。

设置在正常退出时保存到运行目录下 user\config.ini。
随包 BAT 入口会先将工作目录切到程序所在目录，便于找到设置和资源。
存档位于 assets\legacy\runtime 内；升级前请保留旧包或备份自己的存档文件。
不要直接用新包覆盖唯一一份旧目录，以免覆盖存档。

五、需要重启的选项

GPU / 软件场景渲染后端，以及下列光照模式，在启动时选择。
角色阴影实时开关只切换阴影，不切换整个 GPU / 软件渲染后端。

在程序目录打开命令行，可用：

SevenDays.exe --gpu-lighting original
    原版 RGB565 光照，供对照。
SevenDays.exe --gpu-lighting continuous
    连续光照。
SevenDays.exe --gpu-lighting continuous-contrast
    自适应过渡光照（默认）。
SevenDays.exe --gpu-shadows original
    以原版阴影启动，进入后仍可在设置中实时切回柔化。
SevenDays.exe --scene-renderer software
    软件渲染。
SevenDays.exe --scene-size 1920x1440
    更高 GPU 场景分辨率，要求 4:3；开销随分辨率增加。
SevenDays.exe --window-size 1600x1000
    设置启动窗口尺寸，不改变 GPU 场景分辨率。

启动参数可以覆盖已保存设置；不带这些参数则使用默认值或已保存偏好。
光照模式和场景渲染后端当前不在设置文件中保存。

六、预览版说明

需要支持 SDL GPU 后端的显卡和驱动；程序会明确报告 GPU 初始化失败。
直接双击启动时，诊断信息记录在 user\SevenDays.log；若无法启动，可查看此文件或尝试软件对照入口。
本包已在本机 RTX 4070 上验证默认 GPU 场景、阴影选项和软件对照。
柔化阴影仍是地面平面投影，尚未增加墙面 / 家具上的完整场景阴影。

七、音频 MOD

assets\remaster\audio_runtime\windows 中的音频是运行时同名替换资源。
有兴趣改进音效的玩家，可将自己的同名 Ogg Vorbis / WAV 文件放入该目录，
在外部设置把 AUDIO 切为 Remaster，即可在相应声音下次播放时使用。
默认 AUDIO Original 不启用替换；未替换的声音继续使用原版资源。
详细目录、格式优先级和示例见 AUDIO-MOD.txt，原版名称清单见 AUDIO-ASSETS.txt。
