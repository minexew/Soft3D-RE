# Remaster Control UI Assets

These are newly generated remaster UI candidate assets, not imports from the
legacy 7 Days source or runtime package.

## Files

- `remaster-controls-atlas-v2-skeuo.rle`: runtime 32-bit RGBA texture exported
  from the v2 alpha atlas and stored with project-local RLE compression.
- `remaster-controls-atlas-v2-skeuo.slices`: named atlas rectangles used by the
  SDL host renderer.

Source PNGs and layout previews are generated design artifacts. They are kept
out of Git by default because the runtime only needs the `.rle` atlas and
`.slices` manifest.

## Design Intent

- Modern floating controls for PC, iOS, and Android.
- Strict 4:3 game viewport with controls placed in host safe areas.
- D-pad mode preserves original directional controls.
- Stick mode adds a virtual joystick while mapping through the shared action
  layer.
- PC controls support keyboard/mouse, gamepad, and auto source selection.

## Provenance

Generated with Codex `imagegen` on 2026-05-31 for this remaster project.
