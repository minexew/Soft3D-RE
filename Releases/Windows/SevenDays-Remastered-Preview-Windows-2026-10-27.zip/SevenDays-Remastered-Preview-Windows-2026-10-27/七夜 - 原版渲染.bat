@echo off
setlocal
cd /d "%~dp0" || exit /b 1
start "" /normal "%~dp0SevenDays.exe" --scene-renderer software
exit /b %errorlevel%
